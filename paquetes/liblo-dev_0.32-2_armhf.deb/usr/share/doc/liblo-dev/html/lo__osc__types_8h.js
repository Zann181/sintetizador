var lo__osc__types_8h =
[
    [ "LO_TT_IMMEDIATE", "group__liblo.html#gafa8cfc08b763b0c039fb64a73c4c77da", null ],
    [ "lo_element_type", "group__liblo.html#ga08432d01f2b8f4a32ffa58992a821f28", [
      [ "LO_ELEMENT_MESSAGE", "group__liblo.html#gga08432d01f2b8f4a32ffa58992a821f28aef47b7b86b453d77bc37737400a2ad64", null ],
      [ "LO_ELEMENT_BUNDLE", "group__liblo.html#gga08432d01f2b8f4a32ffa58992a821f28a35773b57d50789d1ac7e7e38d2b291c2", null ]
    ] ],
    [ "lo_type", "group__liblo.html#ga11838c576b0197c255ce805fd7434736", [
      [ "LO_INT32", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a4ba0490216baf238719e1200325b037d", null ],
      [ "LO_FLOAT", "group__liblo.html#gga11838c576b0197c255ce805fd7434736ab3245e1b7edacde57f71d200840b0aa3", null ],
      [ "LO_STRING", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a6121bddbedc79af47d86a8a25af47ad2", null ],
      [ "LO_BLOB", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a140f48c944b6c888846b8109ceaeb98b", null ],
      [ "LO_INT64", "group__liblo.html#gga11838c576b0197c255ce805fd7434736acfabb7d6ec1d4f9d033227de24c76b30", null ],
      [ "LO_TIMETAG", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a0516741a260e7109d2b0ed0c92beddbe", null ],
      [ "LO_DOUBLE", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a0ca92c843dfb45f4edabdefd60cdeca6", null ],
      [ "LO_SYMBOL", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a4ae18ed5170672498406c36b16e7a948", null ],
      [ "LO_CHAR", "group__liblo.html#gga11838c576b0197c255ce805fd7434736af93c0cdf731b1edf4b9d44ad7d7dba26", null ],
      [ "LO_MIDI", "group__liblo.html#gga11838c576b0197c255ce805fd7434736ad295b5f7669a7220102082e20fd14ec0", null ],
      [ "LO_TRUE", "group__liblo.html#gga11838c576b0197c255ce805fd7434736ace8c12ac58d6aaee426dc41cfa609009", null ],
      [ "LO_FALSE", "group__liblo.html#gga11838c576b0197c255ce805fd7434736ae85a45e7bc3999069d82da7245d172f4", null ],
      [ "LO_NIL", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a80fcaab02318c562b094ca407f81d2b3", null ],
      [ "LO_INFINITUM", "group__liblo.html#gga11838c576b0197c255ce805fd7434736a9b77e96b653de1f91344549b9b9a0273", null ]
    ] ]
];