var structlo__timetag =
[
    [ "frac", "structlo__timetag.html#a1acce1a3dd765a15c47f6eb76cb96c27", null ],
    [ "sec", "structlo__timetag.html#a917e786d87a5304c5e7ea4d3c44f7cf4", null ]
];